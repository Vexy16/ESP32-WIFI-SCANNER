/*
 * ESP32 Wi-Fi Scanner com display OLED
 *
 * Escaneia as redes Wi-Fi proximas e mostra no OLED (SSID, sinal, canal,
 * seguranca). O botao BOOT (GPIO 0) controla a navegacao:
 *   - clique curto : proxima rede
 *   - clique longo : novo scan
 *
 * Hardware: ESP32 DevKit + OLED SSD1306 128x64 (I2C)
 * Bibliotecas: Adafruit SSD1306 e Adafruit GFX
 */

#include <WiFi.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------- Configuracao ----------
#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT  64      // troque para 32 se seu OLED for 128x32
#define OLED_RESET     -1
#define OLED_ADDRESS   0x3C    // se nao acender, tente 0x3D
#define BUTTON_PIN     0       // botao BOOT embutido
#define LONG_PRESS_MS  800
#define MAX_NETWORKS   30

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

int networkCount = 0;
int order[MAX_NETWORKS];   // indices dos resultados, ordenados por sinal
int current = 0;

// ---------- Utilidades ----------
const char* securityName(wifi_auth_mode_t type) {
  switch (type) {
    case WIFI_AUTH_OPEN:            return "ABERTA";
    case WIFI_AUTH_WEP:             return "WEP";
    case WIFI_AUTH_WPA_PSK:         return "WPA";
    case WIFI_AUTH_WPA2_PSK:        return "WPA2";
    case WIFI_AUTH_WPA_WPA2_PSK:    return "WPA/WPA2";
    case WIFI_AUTH_WPA2_ENTERPRISE: return "WPA2-ENT";
    case WIFI_AUTH_WPA3_PSK:        return "WPA3";
    case WIFI_AUTH_WPA2_WPA3_PSK:   return "WPA2/WPA3";
    default:                        return "?";
  }
}

int signalPercent(int rssi) {
  return constrain(2 * (rssi + 100), 0, 100);
}

void showMessage(const char* line1, const char* line2 = "") {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 20);
  display.println(line1);
  display.println(line2);
  display.display();
}

// ---------- Scan ----------
void scanNetworks() {
  showMessage("Escaneando...", "aguarde");

  int found = WiFi.scanNetworks();
  networkCount = (found > MAX_NETWORKS) ? MAX_NETWORKS : found;
  if (networkCount < 0) networkCount = 0;

  // Ordena por forca do sinal (maior primeiro)
  for (int i = 0; i < networkCount; i++) order[i] = i;
  for (int i = 0; i < networkCount - 1; i++) {
    for (int j = i + 1; j < networkCount; j++) {
      if (WiFi.RSSI(order[j]) > WiFi.RSSI(order[i])) {
        int tmp = order[i];
        order[i] = order[j];
        order[j] = tmp;
      }
    }
  }
  current = 0;

  // Tambem imprime no Serial Monitor (115200)
  Serial.println();
  Serial.printf("%d rede(s) encontrada(s):\n", networkCount);
  for (int i = 0; i < networkCount; i++) {
    int idx = order[i];
    Serial.printf("%2d | %-24s | %4d dBm | canal %2d | %s\n",
                  i + 1, WiFi.SSID(idx).c_str(), WiFi.RSSI(idx),
                  WiFi.channel(idx), securityName(WiFi.encryptionType(idx)));
  }
}

// ---------- Tela ----------
void drawNetwork() {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  if (networkCount == 0) {
    showMessage("Nenhuma rede", "Segure BOOT p/ re-scan");
    return;
  }

  int idx = order[current];
  String ssid = WiFi.SSID(idx);
  if (ssid.length() == 0) ssid = "(rede oculta)";
  if (ssid.length() > 21) ssid = ssid.substring(0, 20) + "~";

  int rssi = WiFi.RSSI(idx);
  int pct = signalPercent(rssi);

  // Cabecalho
  display.setCursor(0, 0);
  display.printf("WiFi Scanner  %d/%d", current + 1, networkCount);
  display.drawLine(0, 10, SCREEN_WIDTH - 1, 10, SSD1306_WHITE);

  // SSID
  display.setCursor(0, 15);
  display.println(ssid);

  // Sinal
  display.setCursor(0, 28);
  display.printf("Sinal: %d dBm (%d%%)", rssi, pct);

  // Barra de sinal
  display.drawRect(0, 40, 100, 8, SSD1306_WHITE);
  display.fillRect(0, 40, pct, 8, SSD1306_WHITE);

  // Canal e seguranca
  display.setCursor(0, 54);
  display.printf("Canal %d  %s", WiFi.channel(idx),
                 securityName(WiFi.encryptionType(idx)));

  display.display();
}

// ---------- Setup / Loop ----------
void setup() {
  Serial.begin(115200);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  Wire.begin(21, 22);  // SDA = GPIO21, SCL = GPIO22

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
    Serial.println("Falha ao iniciar o OLED. Verifique fios e endereco I2C.");
    while (true) delay(1000);
  }

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);

  scanNetworks();
  drawNetwork();
}

void loop() {
  if (digitalRead(BUTTON_PIN) == LOW) {
    unsigned long pressedAt = millis();
    while (digitalRead(BUTTON_PIN) == LOW) delay(10);
    unsigned long duration = millis() - pressedAt;

    if (duration >= LONG_PRESS_MS) {
      scanNetworks();
    } else if (networkCount > 0) {
      current = (current + 1) % networkCount;
    }
    drawNetwork();
  }
  delay(10);
}
